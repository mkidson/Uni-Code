# Challenge 0 for CSC1015
# KDSMIL001
# 7 March 2019

Y = eval(input("Y = "))
X = eval(input("X="))

print("Y = ", Y, sep='')
print("X=", X, sep='')