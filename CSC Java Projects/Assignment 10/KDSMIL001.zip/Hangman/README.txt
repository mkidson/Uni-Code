Author: Miles Kidson, KDSMIL001
Date: 9-10-2019


In order to run the program, open Hangman.java in an IDE and run the program.