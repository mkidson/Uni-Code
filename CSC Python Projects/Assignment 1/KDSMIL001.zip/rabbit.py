# prints a few rabbits
# Miles Kidson KDSMIL001
# 25 February 2019

print("(\\\\               (\/)      ")
print("( '')    (\_/)   (.. )   //)")
print("O(\")(\") (\\'.'/) (\")(\")O (\" )")
print("        (\")_(\")        ()()o")
