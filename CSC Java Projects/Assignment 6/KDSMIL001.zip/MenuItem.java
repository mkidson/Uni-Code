

public class MenuItem {
   
   private String itemNo;
   
   public MenuItem(String itemNo){
      
      this.itemNo = itemNo;
   }
   
   public String getItemNo(){
      
      return this.itemNo;
   }
   
   public String toString(){
      
      return this.itemNo;
   }
}